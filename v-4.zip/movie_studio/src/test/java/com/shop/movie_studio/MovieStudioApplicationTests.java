package com.shop.movie_studio;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MovieStudioApplicationTests {

	@Test
	void contextLoads() {
	}

}
