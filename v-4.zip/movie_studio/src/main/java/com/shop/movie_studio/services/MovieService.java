package com.shop.movie_studio.services;

import com.shop.movie_studio.model.Movie;
import com.shop.movie_studio.repo.MovieRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class MovieService {

    private final MovieRepository movieRepository;

    @Autowired
    public MovieService(MovieRepository movieRepository) {
        this.movieRepository = movieRepository;
    }

    public Movie addMovie(Movie movie) {
        return movieRepository.save(movie);
    }

    public Optional<Movie> findById(Long id){
        return movieRepository.findById(id);
    }

    public Movie updateMovie(String movieTitle, Movie movie) {
        Movie existingMovie = movieRepository.findByMovieTitle(movieTitle);
        if (existingMovie != null) {
            existingMovie.setGenre(movie.getGenre());
            existingMovie.setRunningTime(movie.getRunningTime());
            existingMovie.setDescription(movie.getDescription());
            existingMovie.setImage(movie.getImage());
            existingMovie.setDirector(movie.getDirector());
            existingMovie.setActors(movie.getActors());
            return movieRepository.save(existingMovie);
        }
        return null;
    }

    public List<Movie> getAllMovies() {
        return movieRepository.findAll();
    }

    public Movie getMovieByTitle(String movieTitle) {
        return movieRepository.findByMovieTitle(movieTitle);
    }
}
