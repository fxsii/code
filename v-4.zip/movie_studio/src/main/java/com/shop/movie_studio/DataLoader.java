package com.shop.movie_studio;

import com.shop.movie_studio.model.Movie;
import com.shop.movie_studio.model.User;
import com.shop.movie_studio.repo.MovieRepository;
import com.shop.movie_studio.repo.UserRepository;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

@Component
public class DataLoader implements CommandLineRunner {

    private final MovieRepository movieRepository;
    private final  UserRepository userRepository;

    public DataLoader(MovieRepository movieRepository,UserRepository userRepository) {
        this.movieRepository = movieRepository;
        this.userRepository = userRepository;
    }

    @Override
    public void run(String... args) throws Exception {
        User producer1 = new User();
        producer1.setName("John Smith");
        User producer2 = new User();
        producer2.setName("Smith Herry");
        User producer3 = new User();
        producer3.setName("Tom Cruse");
        User producer4 = new User();
        producer4.setName("Herry Potter");
        User producer5 = new User();
        producer5.setName("Hamza Saeed");

        User director1 = new User();
        director1.setName("Michael Waldly");
        User director2 = new User();
        director2.setName("Wan Walker ");
        User director3 = new User();
        director3.setName("Wexler");
        User director4 = new User();
        director4.setName("Cary");
        User director5 = new User();
        director5.setName("Shelby");

        User actor1 = new User();
        actor1.setName("Tom Hanks");
        User actor2 = new User();
        actor2.setName("Leonardo DiCaprio");
        User actor3 = new User();
        actor3.setName("Brad Pitt");
        User actor4 = new User();
        actor4.setName("Robert Downey Jr.");
        User actor5 = new User();
        actor5.setName("Denzel Washington");


        User actor6 = new User();
        actor6.setName("Johnny Depp");
        User actor7 = new User();
        actor7.setName("Will Smith");
        User actor8 = new User();
        actor8.setName("Matt Damon");
        User actor9 = new User();
        actor9.setName("Tom Cruise");
        User actor10 = new User();
        actor10.setName("Morgan Freeman");

        User actor11 = new User();
        actor11.setName("Chris Hemsworth");
        User actor12 = new User();
        actor12.setName("Ryan Reynolds");
        User actor13= new User();
        actor13.setName("Mark Wahlberg");
        User actor14 = new User();
        actor14.setName("Christian Bale");
        User actor15 = new User();
        actor15.setName("Hugh Jackman");

        producer1 = userRepository.save(producer1);
        producer2 = userRepository.save(producer2);
        producer3 = userRepository.save(producer3);
        producer4 = userRepository.save(producer4);
        producer5 = userRepository.save(producer5);

        director1 = userRepository.save(director1);
        director2 = userRepository.save(director2);
        director3 = userRepository.save(director3);
        director4 = userRepository.save(director4);
        director5 = userRepository.save(director5);

        actor1 = userRepository.save(actor1);
        actor2 = userRepository.save(actor2);
        actor3 = userRepository.save(actor3);
        actor4 = userRepository.save(actor4);
        actor5 = userRepository.save(actor5);

        actor6 = userRepository.save(actor6);
        actor7 = userRepository.save(actor7);
        actor8 = userRepository.save(actor8);
        actor9 = userRepository.save(actor9);
        actor10 = userRepository.save(actor10);
        actor11 = userRepository.save(actor11);
        actor12 = userRepository.save(actor12);
        actor13 = userRepository.save(actor13);
        actor14 = userRepository.save(actor14);
        actor15 = userRepository.save(actor15);

        Movie movie1 = new Movie();
        movie1.setMovieTitle("The Avengers");
        movie1.setReleaseYear(2012);
        movie1.setGenre("Action");
        movie1.setRunningTime(143);
        movie1.setStudioName("Marvel Studios");
        movie1.setStudioAddress("Hollywood");
        movie1.setPrice(33);
        movie1.setDescription("Earth's mightiest heroes come together to save the world from a powerful threat.");
        movie1.setImage("https://w0.peakpx.com/wallpaper/34/966/HD-wallpaper-the-avengers-avengers-endgame-avengers-avengers-endgame-thumbnail.jpg");
        movie1.setProducer(producer1);
        movie1.setDirector(director1);
        movie1.getActors().add(actor1);
        movie1.getActors().add(actor2);
        movie1.getActors().add(actor15);

        Movie movie2 = new Movie();
        movie2.setMovieTitle("The Shawshank Redemption");
        movie2.setReleaseYear(1994);
        movie2.setGenre("Drama");
        movie2.setRunningTime(142);
        movie2.setPrice(13);

        movie2.setStudioName("Castle Rock Entertainment");
        movie2.setStudioAddress("Los Angeles");
        movie2.setDescription("Two imprisoned men bond over several years, finding solace and eventual redemption through acts of common decency.");
        movie2.setImage("https://www.filmonpaper.com/wp-content/uploads/2012/01/TheShawshankRedemption_onesheet_10thAnniversaryReRelease_USA_DrewStruzan-3.jpg");
        movie2.setProducer(producer2);
        movie2.setDirector(director2);
        movie2.getActors().add(actor3);
        movie2.getActors().add(actor4);
        movie2.getActors().add(actor14);

        Movie movie3 = new Movie();
        movie3.setMovieTitle("Inception");
        movie3.setReleaseYear(2010);
        movie3.setGenre("Sci-Fi");
        movie3.setRunningTime(148);
        movie3.setStudioName("Legendary Pictures");
        movie3.setStudioAddress("California");
        movie3.setPrice(22);
        movie3.setDescription("A thief with the ability to enter people's dreams is tasked with planting an idea into the mind of a CEO.");
        movie3.setImage("https://e1.pxfuel.com/desktop-wallpaper/323/735/desktop-wallpaper-inception-movie-inception-thumbnail.jpg");
        movie3.setProducer(producer3);
        movie3.setDirector(director3);
        movie3.getActors().add(actor5);
        movie3.getActors().add(actor6);
        movie3.getActors().add(actor7);
        movie3.getActors().add(actor8);

        Movie movie4 = new Movie();
        movie4.setMovieTitle("The Dark Knight");
        movie4.setReleaseYear(2008);
        movie4.setGenre("Action");
        movie4.setRunningTime(152);
        movie4.setPrice(50);
        movie4.setStudioName("Warner Bros.");
        movie4.setStudioAddress("Burbank");
        movie4.setDescription("Batman, with the help of Lieutenant Jim Gordon and District Attorney Harvey Dent, sets out to dismantle the remaining criminal organizations in Gotham City.");
        movie4.setImage("https://www.vintagemovieposters.co.uk/wp-content/uploads/2015/01/IMG_5848.jpeg");
        movie4.setProducer(producer4);
        movie4.setDirector(director4);
        movie4.getActors().add(actor9);
        movie4.getActors().add(actor10);

        Movie movie5 = new Movie();
        movie5.setMovieTitle("Pulp Fiction");
        movie5.setReleaseYear(1994);
        movie5.setGenre("Crime");
        movie5.setRunningTime(154);
        movie5.setPrice(29);
        movie5.setStudioName("Miramax Films");
        movie5.setStudioAddress("New York");
        movie5.setDescription("Various interconnected stories of criminals, mobsters, and lowlifes intertwine in the seedy underbelly of Los Angeles.");
        movie5.setImage("https://www.limitedruns.com/media/cache/75/a9/75a980237d779d1295fa36551e74a019.jpg");
        movie5.setProducer(producer5);
        movie5.setDirector(director5);
        movie5.getActors().add(actor11);
        movie5.getActors().add(actor12);
        movie5.getActors().add(actor13);

        movieRepository.save(movie1);
        movieRepository.save(movie2);
        movieRepository.save(movie3);
        movieRepository.save(movie4);
        movieRepository.save(movie5);
    }
}
