package com.shop.movie_studio.controller;


import com.shop.movie_studio.model.Movie;
import com.shop.movie_studio.model.User;
import com.shop.movie_studio.model.UserType;
import com.shop.movie_studio.services.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

@Controller
public class UserController {

    private UserService userService;

    @Autowired
    public UserController(UserService userService) {
        this.userService = userService;
    }

    @GetMapping("/signup")
    public String showSignupForm(Model model) {
        model.addAttribute("user", new User());
        return "signup";
    }

    @PostMapping("/signup")
    public String processSignupForm(@ModelAttribute("user") User user) {
        user.setUserType(UserType.CUSTOMER);
        userService.signUp(user.getName(), user.getUsername(), user.getDateOfBirth(), user.getPassword(), user.getUserType());

        // Redirect to a success page or perform additional logic
        return "redirect:/login";
    }

    @GetMapping("/login")
    public String showLoginForm(Model model) {
        model.addAttribute("user", new User());
        return "login";
    }



    @GetMapping("/studio")
    public String studioPage(Model model) {
        model.addAttribute("movie", new Movie());
        return "studio";
    }
    @PostMapping("/login")
    public String processLoginForm(@ModelAttribute("user") User user) {
        // Extract form data and call the UserService to perform login
        User loggedInUser = userService.login(user.getUsername(), user.getPassword());

        if (loggedInUser != null) {
            // Successful login
            // Perform additional logic or redirect to the home page
            return "redirect:/movies";
        } else {
            // Failed login
            // Display error message or redirect to a login error page
            return "redirect:/login";
        }
    }
}