package com.shop.movie_studio.model;
public enum UserType {
    ACTOR,
    PRODUCER,
    DIRECTOR,
    CUSTOMER
}