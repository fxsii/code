package com.shop.movie_studio.repo;

import com.shop.movie_studio.model.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface UserRepository extends JpaRepository<User, Long> {

    User findByUsername(String username);

    // Other custom queries or methods

    // ...
}
