package com.shop.movie_studio.services;

import com.shop.movie_studio.model.User;
import com.shop.movie_studio.model.UserType;
import com.shop.movie_studio.repo.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class UserService {

    private UserRepository userRepository;

    @Autowired
    public UserService(UserRepository userRepository) {
        this.userRepository = userRepository;
    }

    public User signUp(String name,String username, String dateOfBirth, String password, UserType userType) {
        User user = new User();
        user.setUsername(username);
        user.setName(name);
        user.setDateOfBirth(dateOfBirth);
        user.setPassword(password);
        user.setUserType(userType);
        return userRepository.save(user);
    }

    public User login(String name, String password) {
        User user = userRepository.findByUsername(name);
        if (user != null && user.getPassword().equals(password)) {
            return user;
        }
        return null;
    }
}
