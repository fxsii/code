package com.shop.movie_studio.controller;

import com.shop.movie_studio.model.Movie;
import com.shop.movie_studio.services.MovieService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Controller
public class MovieController {

    private final MovieService movieService;

    @Autowired
    public MovieController(MovieService movieService) {
        this.movieService = movieService;
    }

    @PostMapping
    public ResponseEntity<Movie> addMovie(@RequestBody Movie movie) {
        Movie createdMovie = movieService.addMovie(movie);
        return new ResponseEntity<>(createdMovie, HttpStatus.CREATED);
    }

    @PutMapping("/{movieTitle}")
    public ResponseEntity<Movie> updateMovie(@PathVariable("movieTitle") String movieTitle, @RequestBody Movie movie) {
        Movie updatedMovie = movieService.updateMovie(movieTitle, movie);
        if (updatedMovie != null) {
            return new ResponseEntity<>(updatedMovie, HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

    @GetMapping("/get/movies")
    public ResponseEntity<List<Movie>> getAllMovies() {
        List<Movie> movies = movieService.getAllMovies();
        return new ResponseEntity<>(movies, HttpStatus.OK);
    }

    @GetMapping("/movie/{movieTitle}")
    public String getMovieDetails(@PathVariable String movieTitle, Model model) {
        Movie movie = movieService.getMovieByTitle(movieTitle);
        if (movie == null) {
            return "error"; // Handle error case when movie is not found
        }
        model.addAttribute("movie", movie);
        return "movie";
    }


    @GetMapping("/movies")
    public String getMovies(@RequestParam(name = "searchTitle",  required = false) String searchTitle, Model model) {
        List<Movie> movies = movieService.getAllMovies();
        if (searchTitle != null && !searchTitle.isEmpty()) {
            movies = movies.stream()
                    .filter(movie -> movie.getMovieTitle().toLowerCase().contains(searchTitle.toLowerCase())
                            || movie.getProducer().getName().toLowerCase().contains(searchTitle.toLowerCase())
                            || movie.getDirector().getName().toLowerCase().contains(searchTitle.toLowerCase())
                            || movie.getActors().stream()
                            .anyMatch(actor -> actor.getName().toLowerCase().contains(searchTitle.toLowerCase())))
                    .collect(Collectors.toList());
        }
        model.addAttribute("movies", movies);
        return "movies";
    }


    @GetMapping("/favorites")
    public String getfavorites(@RequestParam(name = "searchTitle",  required = false) String searchTitle, Model model) {
        List<Movie> movies = movieService.getAllMovies().stream().filter(m->m.isFav()).collect(Collectors.toList());
        if (searchTitle != null && !searchTitle.isEmpty()) {
            movies = movies.stream()
                    .filter(movie -> movie.getMovieTitle().toLowerCase().contains(searchTitle.toLowerCase())
                            || movie.getProducer().getName().toLowerCase().contains(searchTitle.toLowerCase())
                            || movie.getDirector().getName().toLowerCase().contains(searchTitle.toLowerCase())
                            || movie.getActors().stream()
                            .anyMatch(actor -> actor.getName().toLowerCase().contains(searchTitle.toLowerCase())))
                    .collect(Collectors.toList());
        }
        model.addAttribute("movies", movies);
        return "movies";
    }

    @PostMapping("/movies/favorite/{id}")
    public ResponseEntity<?> toggleFavorite(@PathVariable("id") Long id) {
        Optional<Movie> optionalMovie = movieService.findById(id);
        if (optionalMovie.isPresent()) {
            Movie movie = optionalMovie.get();
            movie.setFav(!movie.isFav());
            movieService.addMovie(movie);
            return ResponseEntity.ok().build();
        } else {
            return ResponseEntity.notFound().build();
        }
    }


    @PostMapping("/movies")
    public String postMovie(@ModelAttribute("movie") Movie movie) {
        System.out.println(movie);
        return "redirect:/login";
    }
}
